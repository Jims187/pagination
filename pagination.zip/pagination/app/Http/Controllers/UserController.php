<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;

class UserController extends Controller
{
    //
    public function showAllUser(Request $request){
        $page =1;
        $maxlimit =3;
        $start_from = ($page-1) * $maxlimit;
        

        $user =User::offset($start_from)->limit($maxlimit)->orderBy('created_at')->get();
        $userCount =User::offset($start_from)->limit($maxlimit)->orderBy('created_at')->count();
        return view('pagination.index',['users' => $user,'userCount' => $userCount,'limit' => $maxlimit]);
    }
    public function getUserByPages(Request $request){
        $page = $request->pageno;
        $maxlimit= $request->limit;
        $start_from= ($page-1) * $maxlimit;

        $user =User::offset($start_from)->limit($maxlimit)->orderBy('created_at')->get();
        $userCount =User::all()->count();
    
        return response()->json(array('users' => $user, 'count' => $userCount), 200);
    }
}
