<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.3/jquery.min.js"></script>

    <style>
        table {
          font-family: arial, sans-serif;
          border-collapse: collapse;
          width: 100%;
        }
        
        td, th {
          border: 1px solid #dddddd;
          text-align: left;
          padding: 8px;
        }
        
        tr:nth-child(even) {
          background-color: #dddddd;
        }
        .pagelinks{
       
       display: flex;
       flex-wrap: wrap;
       justify-content: center;
       margin-top: 30px;
       margin-bottom: 30px;
   }
   #pagelink{
        margin-top: 4px;
       margin-left: 6px;
   }
   .pagination-dots
   {
       display: flex;
       align-items: center;
       padding-left: 4px;
   }
   .dots{
       margin-top: 4px;
   }
   .pagelinks a{
       padding: 5px 8px;
      background-color: #c7c7c7;
       color: black;
       text-align: center;
       text-decoration: none;
       display: inline-block;  
   }
        </style>
</head>
<body>
    <table class="row">
        <thead>
            <tr>
             
                <th>No</th>
                <th>Name</th>
                <th>Email</th>
            </tr>
        </thead>
        @foreach ($users as $user)
        <tr class="row">
            
            <td>{{$user->id}}</td>
            <td>{{$user->name}}</td>
            <td>{{$user->email}}</td>   
           
            
        </tr>
        @endforeach
    </table>
    <div class="pagelinks" style="margin-top: 10px;">

    </div>
</body>
</html>
<script>
  var limit = {{$limit}};
  var currentPage = 1;
  $(document).ready(function(){
var userCount = {{$userCount}};
pages = Math.ceil(userCount/limit);
updatePagination(pages,1,10);
  });

$(document).on('click','.pagelink', function(e){
  e.preventDefault();
  if($(this).text() == "Previous"){
    currentPage = currentPage -1;
  }else if($(this).text() == "Next"){
    if(currentPage < pages)
    currentPage = currentPage + 1;
  }
  else{
    currentPage = parseInt($(this).text());
    $.ajax({
      type: "GET",
      url: '/getUserByPages',
      data : {
        pageno: currentPage,
        limit: limit,
      },
      success: function(response){
        changeHtml(response);
        
        pages = Math.ceil(response.count/limit);
        updatePagination(pages,currentPage,10);
      }
    })
  }
});
  
  function updatePagination(pages,page,max_pagelinks_toshow)
    {
      
         var htmlPagination=""
    
     if(pages>0)
     htmlPagination += `<a class='pagelink' id='pagelink' href=''>Previous</a>`;
    
    if (pages >=1 && page <= pages)
    {
        var counter = 1;
        
        if (page > 1)
           { htmlPagination += `<a class='pagelink' id='pagelink' href=''>1 </a> `;}
       
        for (var x=page; x<pages;x++)
        {

            if(counter < (max_pagelinks_toshow-2) )
                {
                    if(x==page)
               htmlPagination += `<a id='pagelink' class='pagelink' href='' style='background-color: green; color:white'>${x}</a>`;
                    else
                        htmlPagination += `<a id='pagelink' class='pagelink' href=''>${x}</a>`;
                        

            counter++;
                }
         
        }
        
        if(page==pages)
       htmlPagination += `<a id='pagelink' class='pagelink' href='' style='background-color: green; color:white'>${pages}</a>`; 
        else
              htmlPagination += `<a id='pagelink' class='pagelink' href=''>${pages}</a>`; 
            
        
       
    }
         if(pages>0)
         htmlPagination += `<a id='pagelink' class='pagelink' href=''>Next</a>`;
        
        if(pages==1 || pages < 0){
            $(".pagelinks").empty();
             
        }
       
       else{
        
        $(".pagelinks").empty();
        $(".pagelinks").html(htmlPagination);
       }
    }
    function changeHtml(data){
      $('.row').empty();
      var html =``;
      html += `
      <thead>
            <tr>
             
                <th>No</th>
                <th>Name</th>
                <th>Email</th>
            </tr>
        </thead>`;
        for(var i=0; i < data.users.length; i++){
html += `<tr class="row">
            
            <td>${data.users[i].id}</td>
            <td>${data.users[i].name}</td>
            <td>${data.users[i].email}</td>   
           
            
        </tr>
      
      `;
        }
        $('.row').html(html);
        
      
    }
</script>